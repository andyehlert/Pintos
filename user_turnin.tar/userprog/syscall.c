#include "userprog/syscall.h"
#include <stdio.h>
#include <syscall-nr.h>
#include "threads/interrupt.h"
#include "threads/thread.h"
#include "threads/vaddr.h"
#include "userprog/pagedir.h"
#include "devices/shutdown.h"
#include "filesys/filesys.h"
#include "filesys/file.h"
#include "threads/synch.h"
#include "userprog/process.h"
#include <list.h>

static void syscall_handler (struct intr_frame *);
static struct lock sys_lock;

void
syscall_init (void) 
{
	lock_init(&sys_lock);
	intr_register_int (0x30, 3, INTR_ON, syscall_handler, "syscall");
}

/* Struct used to reference files through file descriptors */
struct file_info{
	int fd;
	struct list_elem elem;
	struct file * f; 
};

/* Function declarations */
/* Andy driving here */
void fi_init(int fd, struct file * point, struct file_info * desc);
struct file* find_file(int fd);
void halt(void);
void exit(int status);
bool check_args(int args, uint32_t *esp);
tid_t exec(const char *cmd_line);
// int wait(tid_t tid);
bool create(const char *file, unsigned initial_size);
// bool remove(const char *file);
int open(const char *file);
int filesize(int fd);
// int read(int fd, void *buffer, unsigned size);
int write(int fd, const void *buffer, unsigned size);
void seek(int fd, unsigned position);
unsigned tell(int fd);
void close(int fd);


/* Function used to initialize file_info structs */
void fi_init(int fd, struct file * point, struct file_info * desc){
	desc->fd = fd;
	desc->f = point;
}

struct file*
find_file(int fd)
{
	int index = 0;
	int size = list_size(&thread_current()->open_files);
	if(size == 0)
		return NULL;

	struct list_elem *current = list_front(&thread_current()->open_files);
	struct file_info *file_curr;
	while(index < size)
	{
		file_curr = list_entry (current, struct file_info, elem);
		if(file_curr->fd == fd)
		{
			return file_curr->f;
		}
		current = list_next(current);
		index++;
	}
	return NULL;
}

static void //switch table that calls methods based on the appropriate system call
syscall_handler (struct intr_frame *f) 
{
	//Steve Driving
	/* Declares a copy of the stack pointer given by the interrupt frame */
	uint32_t *esp_copy = f->esp;

	/* Switch statement based on the given system call number */
	switch(*esp_copy)
	{
		/* Case handles a halt system call */
		case SYS_HALT:
			halt();
			break;

		/* Case handles an exit system call */
		case SYS_EXIT:
			if(check_args(1, esp_copy))
			{
				uint32_t e_stat = *(uint32_t *) (esp_copy + 1);
				printf("%s: exit(%d)\n", thread_current()->name, e_stat);
				exit(e_stat);
			}
			thread_exit();
			break;

		/* Case handles an exec system call */
		case SYS_EXEC:
			if(check_args(1, esp_copy))
			{
				tid_t result = exec((char *) *(esp_copy + 1));
				f->eax = (uint32_t) result;
			}
			break;

		/* Case handles a wait system call */
		case SYS_WAIT:
			if(check_args(1, esp_copy))
			{
				f->eax = (uint32_t) process_wait(*(uint32_t*)f->esp +1);
			}
			break;
			
		/* Case handles a remove system call */
		case SYS_REMOVE:
			if(check_args(1, esp_copy))
			{
				
			}
			break;
			
		/* Case handles an open system call */
		case SYS_OPEN:
			// lock_acquire(&sys_lock);
			if(check_args(1, esp_copy + 1))
			{
				char *f_open = (char *) *(esp_copy + 1);
				f->eax = (uint32_t) open(f_open);
			}
			break;
			
		/* Case handles a filesize system call */
		case SYS_FILESIZE:
			if(check_args(1, esp_copy))
			{
				uint32_t fd = *(uint32_t *) (esp_copy + 1);
				f->eax = (uint32_t) filesize(fd);
			}
			break;
			
		/* Case handles a tell system call */
		case SYS_TELL:
			if(check_args(1, esp_copy))
			{
				uint32_t fd = *(uint32_t *) (esp_copy + 1);
				f->eax = (uint32_t) tell(fd);				
			}
			break;
			
		/* Case handles a close system call */
		case SYS_CLOSE:
			if(check_args(1, esp_copy))
			{
				uint32_t fd = *(uint32_t *) (esp_copy + 1);
				close(fd);			
			}
			break;

		/* Case handles a create system call */
		case SYS_CREATE:
			if(check_args(2, esp_copy))
			{
				char *f_open = (char *) *(esp_copy + 1);
				uint32_t size = *(uint32_t *) (esp_copy + 2);
				f->eax = (uint32_t) create(f_open, size);
			}
			break;
			
		/* Case handles a seek system call */
		case SYS_SEEK:
			if(check_args(2, esp_copy))
			{
				int32_t fd = *(int32_t *) (esp_copy + 1);
				uint32_t position = *(uint32_t *) (esp_copy + 2);
				seek(fd, position);
			}
			break;

		/* Case handles a read system call */
		case SYS_READ:
			if(check_args(3, esp_copy))
			{
				
			}
			break;
			
		/* Case handles a write system call */
		case SYS_WRITE:
			if(check_args(3, esp_copy))
			{
				uint32_t fd = *((uintptr_t *) f->esp + 1);
				char *buf = *((uintptr_t *) f->esp + 2);
				
				uint32_t size = *((uintptr_t *)f->esp + 3);
				f->eax = (uint32_t) write(fd, buf, size);
			}
			break;

		default:
			thread_exit();
			break;

	}
}

//Zach Driving
/* Function to check the validity of user provided pointers */
bool check_args(int args, uint32_t *esp)
{
	int index = args;
	while(index > 0)
	{
		/* Checks to see if user provided pointer is valid, page fault if it is invalid */
		if(*(esp) >= PHYS_BASE 
			|| pagedir_get_page(thread_current()->pagedir, esp) == NULL 
			|| *esp == NULL 
			|| *esp == 0)
		{
			printf("%s: exit(%d)\n", thread_current()->name, -1);
			thread_current()-> exit_status = -1;
			thread_exit();
		}
		index--;
		esp++;
	}
	esp -= args;
	return true;
}


void halt(void)//shut down
{
	shutdown_power_off();
}

void exit(int status) //changes the exit status of the thread
{
	lock_acquire(&thread_current()->child_lock);
	thread_current()->exit_status = status;
	lock_release(&thread_current()->child_lock);
}
//Andy Driving
tid_t exec(const char *cmd_line)//gives a new program to a process using process_execute
{
	tid_t result = process_execute(cmd_line);
	if(result == TID_ERROR)
		return -1;
	return result;
}

bool create(const char *file, unsigned initial_size)
{
	if(file == NULL)
		return -1;
	return filesys_create(file, (off_t) initial_size);
}

// bool remove(const char *file)
// {

// }

int open(const char *file)//opens the specified file
{
	/* Jerry Driving */
	/* Create struct with file descriptor, file name, and list elem */
	struct file * point = filesys_open(file);
	if(point == NULL)
	{
		return -1;
	}
	else
	{
		struct file_info descript;
		fi_init(thread_current()->fd, point, &descript);
		list_push_front(&thread_current()->open_files, &descript.elem);
		thread_current()->fd++;
		return descript.fd;
	}
}

int filesize(int fd)//returns the file size of the file specified by fd
{
	struct file* file = find_file(fd);
	return (uint32_t) file_length(file);
}

// int read(int fd, void *buffer, unsigned size)
// {

// }


//if fd = 1 writes to stdout, else writes to the specified file
int write(int fd, const void *buffer, unsigned size) 
{
	if(fd == 1)
	{
		putbuf((char *) buffer, size);
		return size;
	}
	else
	{
		struct file *file = find_file(fd);
		if(file == NULL)
		{
			return -1;
		}
		return (int) file_write(file, buffer, size);
	}
}

void seek(int fd, unsigned position)
{
	int index = 0;
	int size = list_size(&thread_current()->open_files);
	struct list_elem *current = list_front(&thread_current()->open_files);
	struct file_info *file_curr;
	while(index < size)
	{
		file_curr = list_entry (current, struct file_info, elem);
		if(file_curr->fd == fd)
		{
			file_seek(file_curr->f, (off_t) position);
			break;
		}
		current = list_next(current);
		index++;
	}
}

unsigned tell(int fd)
{
	int index = 0;
	int size = list_size(&thread_current()->open_files);
	struct list_elem *current = list_front(&thread_current()->open_files);
	struct file_info *file_curr;
	while(index < size)
	{
		file_curr = list_entry (current, struct file_info, elem);
		if(file_curr->fd == fd)
		{
			uint32_t pos = (uint32_t) file_tell(file_curr->f);
			return (pos + 1);
		}
		current = list_next(current);
		index++;
	}
	return -1;
}
//Steve Driving
void close(int fd)//closes the specified file
{
	int index = 0;
	int size = list_size(&thread_current()->open_files);
	struct list_elem *current = list_front(&thread_current()->open_files);
	struct file_info *file_curr;
	while(index < size)
	{
		file_curr = list_entry (current, struct file_info, elem);
		if(file_curr->fd == fd)
		{
			file_close(file_curr->f);
			file_curr->fd = -1;
		}
		current = list_next(current);
		index++;
	}
}
